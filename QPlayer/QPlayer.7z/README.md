# @[QPlayer](https://github.com/Jrohy/QPlayer)
一款简洁小巧的HTML5底部悬浮音乐播放器. 效果展示: https://32mb.space

##界面
![QPlayer.PNG][1]

##Tips
此版本为纯网页版， 建议有插件冲突的 或 PJAX难以实现的， 使用此版本自定义加入到网页里

欢迎Fork添加无限可能


 [1]: https://32mb.space/usr/uploads/2016/08/858331127.png

 [2]: https://camo.githubusercontent.com/42b56f599b52a82e158df8f7cd1717278c0f274b/68747470733a2f2f33326d622e73706163652f7573722f75706c6f6164732f323031362f30382f3835383333313132372e706e67